export const config = {
    client: "better-sqlite3",
    connection: {
      filename: "./DB/mydb.sqlite"
    },
    useNullAsDefault: true,
  };
  